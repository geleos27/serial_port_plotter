case ILI9488:

	LCD_Write_COM(0x01);
	delay(50);

	LCD_Write_COM(0x28);	

	LCD_Write_COM(0xC0);		// ?????
	LCD_Write_DATA(0x10);
	LCD_Write_DATA(0x10);

	LCD_Write_COM(0xC1);		// ?????
	LCD_Write_DATA(0x41);

	LCD_Write_COM(0xC5);		// ?????
	LCD_Write_DATA(0x00);
	LCD_Write_DATA(0x22);
	LCD_Write_DATA(0x08);
	LCD_Write_DATA(0x40);

	LCD_Write_COM(0x36);		// 
	LCD_Write_DATA(0x68);
	
	LCD_Write_COM(0xB0);
	LCD_Write_DATA(0x00);

	LCD_Write_COM(0xB1);
	LCD_Write_DATA(0xB0);
	LCD_Write_DATA(0x11);

	LCD_Write_COM(0xB4);		// 
	LCD_Write_DATA(0x02);
	
	LCD_Write_COM(0xB6);		// 
	LCD_Write_DATA(0x02);
	LCD_Write_DATA(0x02);
	LCD_Write_DATA(0x3B);

	LCD_Write_COM(0xB7);		// 
	LCD_Write_DATA(0xC6);
		
	LCD_Write_COM(0x3A);		// 
	LCD_Write_DATA(0x55);
	
	LCD_Write_COM(0xF7);		
	LCD_Write_DATA(0xA9);
	LCD_Write_DATA(0x51);		
	LCD_Write_DATA(0x2C);
	LCD_Write_DATA(0x82);

	LCD_Write_COM(0x11);		// Display Inversion OFF
	LCD_Write_DATA(0x00);		//C8 	 

	delay(120);
	
	LCD_Write_COM(0x29);		// Display ON
	LCD_Write_COM(0x00);		// Memory Write
	break;
